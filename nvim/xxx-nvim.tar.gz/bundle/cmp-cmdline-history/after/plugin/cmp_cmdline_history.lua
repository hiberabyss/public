require('cmp').register_source('cmdline_history', require('cmp_cmdline_history').new())
