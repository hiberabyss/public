return {
	s("trig2", fmt("this {} also works :))", { i(1) })),
}
