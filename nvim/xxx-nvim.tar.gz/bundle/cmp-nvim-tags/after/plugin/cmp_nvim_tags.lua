require'cmp'.register_source('tags', require'cmp_nvim_tags'.new())
