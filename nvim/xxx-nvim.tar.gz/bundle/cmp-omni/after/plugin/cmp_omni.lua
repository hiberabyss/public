require('cmp').register_source('omni', require('cmp_omni').new())
